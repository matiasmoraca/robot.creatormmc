package robot.creatormmc;

public class Manommc {
	private int numDedos;
	
	public Manommc() {
		
		this.numDedos= 5;
		System.out.print("la mano del robot tiene 5 dedos");
	}
	
	
	public int getNumDedosmmc() {
		
		return numDedos;
		
	
		
	}
	
      public void golpemmc() {
		
		System.out.print(" la mano lanza un golpe de karate ");
	}
}
