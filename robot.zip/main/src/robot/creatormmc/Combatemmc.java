package robot.creatormmc;


	public class Combatemmc  extends Outfitmmc {
	    public Combatemmc () {
	        this.descripcion = "Outfit para combate callejero";
	    }
	}


