package robot.creatormmc;

public abstract class Outfitmmc {
    protected String descripcion;

    public String getDescripcion() {
        return descripcion;
    }
}
