package robot.creatormmc;

public class Piernammc {

	    private boolean patadaMmc;

	    public Piernammc() {
	        this.patadaMmc = false;
	    }

	    public void lapatadammc() {
	        patadaMmc = true;
	        System.out.println("La pierna hace una patada de karate.");
	    }

	    public boolean isPatadammc() {
	        return patadaMmc;
	    }
	}


