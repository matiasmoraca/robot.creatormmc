package robot.creatormmc;

public class Cabezammc {

	    private String colorCabellommc;

	    public Cabezammc(String colorCabellommc) {
	        this.colorCabellommc = colorCabellommc;
	    }

	    public void girarCabezammc() {
	        System.out.println("Esquiva el golpe girando la cabeza.");
	    }

	    public String getColorCabellommc() {
	        return colorCabellommc;
	    }
	}


