package robot.creatormmc;

public class Torsommc {
	
	    private String materialmmc;

	    public Torsommc(String materialmmc) {
	        this.materialmmc = materialmmc;
	    }

	    public void Endurecermmc() {
	        System.out.println("Mostrando abdominales del robot");
	    }

	    public String getMaterialmmc() {
	        return materialmmc;
	    }
	}


