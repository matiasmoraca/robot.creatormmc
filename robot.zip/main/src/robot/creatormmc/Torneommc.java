package robot.creatormmc;

public class Torneommc  extends Outfitmmc {
    public Torneommc () {
        this.descripcion = "Outfit para torneo";
    }
}
